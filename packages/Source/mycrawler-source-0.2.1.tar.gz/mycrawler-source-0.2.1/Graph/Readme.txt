This component of graph spacialization was developed by Gauthier Sornet.
For more information, please contact : TheGhostTiger@gmail.com