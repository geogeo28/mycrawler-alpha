/****************************************************************************
 * @(#) Data container.
 *
 * Copyright (C) 2009 by ANNEHEIM Geoffrey and PORTEJOIE Julien
 * Contact: geoffrey.anneheim@gmail.com / julien.portejoie@gmail.com
 *
 * GNU General Public License Usage
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3.0 as published
 * by the Free Software Foundation and appearing in the file LICENSE.TXT
 * included in the packaging of this file.  Please review the following
 * information to ensure the GNU General Public License version 3.0
 * requirements will be met: http://www.gnu.org/copyleft/gpl.html.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * RCSID $Id: DataContainer.h 156 2009-05-30 16:40:58Z geoffrey.anneheim $
 ****************************************************************************/

#ifndef DATACONTAINER_H
#define DATACONTAINER_H

#include <QMap>

class QString;
class QVariant;

class CDataContainer
{
    typedef QMap<QString, QVariant> DataList;

public:
    CDataContainer();

    void setData(const QString& name, const QVariant& data);
    QVariant data(const QString& name) const;

private:
    DataList m_lstData;
};

#endif // DATACONTAINER_H
